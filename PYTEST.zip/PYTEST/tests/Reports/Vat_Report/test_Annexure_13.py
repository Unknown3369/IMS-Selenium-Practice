import pytest
import allure
from selenium.webdriver.support.ui import WebDriverWait
from PYTEST.pages.Login import login
from PYTEST.pages.Reports.Vat_Report.Annexure_13 import Annexure13ReportPage


# noinspection PyBroadException
@allure.title("Generate Annexure 13 Report in IMS Application")
@allure.description("Logs in, navigates to Annexure 13 Report, clicks RUN, and verifies the report table.")
def test_annexure_13_report(driver):
    driver = driver
    wait = WebDriverWait(driver, 30)
    login_page = login(driver)

    try:
        login_page.perform_login("Testuser", "Test@1234")
        print("Logged into IMS")

        annexure_13_report = Annexure13ReportPage(driver)
        annexure_13_report.generate_annexure_13_report()

        print("Annexure 13 Report generated successfully.")

        # Screenshot on success
        allure.attach(
            driver.get_screenshot_as_png(),
            name="Annexure_13_Report_Success",
            attachment_type=allure.attachment_type.PNG
        )

    except Exception as e:

        # Screenshot on failure
        allure.attach(
            driver.get_screenshot_as_png(),
            name="Annexure_13_Report_Error",
            attachment_type=allure.attachment_type.PNG
        )

        # Attach exception details
        allure.attach(
            str(e),
            name="Error Details",
            attachment_type=allure.attachment_type.TEXT
        )

        pytest.fail(f"Test failed due to: {e}")

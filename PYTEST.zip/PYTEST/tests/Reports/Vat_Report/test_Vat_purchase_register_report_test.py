import pytest
import allure
from selenium.webdriver.support.ui import WebDriverWait
from PYTEST.pages.Login import login
from PYTEST.pages.Reports.Vat_Report.Vat_Purchase_Register_Report import VatPurchaseRegisterReportPage


# noinspection PyBroadException
@allure.title("Generate Vat Purchase Register Report in IMS Application")
@allure.description("Logs in, navigates to Vat Purchase Register Report, selects supplier, and runs the report.")
def test_vat_purchase_register_report(driver):
    wait = WebDriverWait(driver, 30)
    login_page = login(driver)

    try:
        login_page.perform_login("Testuser", "Test@1234")
        print("Logged into IMS")

        vat_purchase_report = VatPurchaseRegisterReportPage(driver)
        vat_purchase_report.generate_vat_purchase_register_report()

        print("Vat Purchase Register Report generated successfully.")

        allure.attach(
            driver.get_screenshot_as_png(),
            name="Vat_Purchase_Register_Success",
            attachment_type=allure.attachment_type.PNG
        )

    except Exception as e:

        # Screenshot on failure
        allure.attach(
            driver.get_screenshot_as_png(),
            name="Vat_Purchase_Register_Error",
            attachment_type=allure.attachment_type.PNG
        )

        # Attach exception details
        allure.attach(
            str(e),
            name="Error Details",
            attachment_type=allure.attachment_type.TEXT
        )

        pytest.fail(f"Test failed due to: {e}")

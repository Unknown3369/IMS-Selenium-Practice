import pytest
import allure
from selenium.webdriver.support.ui import WebDriverWait
from PYTEST.pages.Login import login
from PYTEST.pages.Masters.Add_Product_Category import AddProductCategoryPage


# noinspection PyBroadException
@allure.title("Add Product Category in IMS Application")
@allure.description("Logs in, navigates to Product Category page, and adds a new category named 'Hygiene'.")
def test_add_product_category(driver):
    login_page = login(driver)

    try:

        login_page.perform_login("Testuser", "Test@1234")
        print("Logged into IMS")

        # --- Step 2: Navigate to Product Category page ---
        add_category = AddProductCategoryPage(driver)
        add_category.navigate_to_add_product()

        # --- Step 3: Add Product Category ---
        add_category.add_product_category("Liquor")
        print("Product category 'Liquor' added successfully.")

        # Screenshot for success proof
        allure.attach(driver.get_screenshot_as_png(), name="Add_Product_Category_Success", attachment_type=allure.attachment_type.PNG)

    except Exception as e:
        # Capture screenshot and log error details for Allure
        allure.attach(driver.get_screenshot_as_png(), name="Add_Product_Category_Error", attachment_type=allure.attachment_type.PNG)
        allure.attach(str(e), name="Error Details", attachment_type=allure.attachment_type.TEXT)
        pytest.fail(f"Test failed due to: {e}")

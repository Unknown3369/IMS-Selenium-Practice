import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

class Vendor:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(self.driver, 25)
        self.actions = ActionChains(self.driver)

    # ---------------- Vendor CREATION SECTION ----------------
    def hover_and_click(self, element):
        """Helper method to hover and click using ActionChains"""
        self.actions.move_to_element(element).click().perform()

    def scroll_and_click(self, element):
        """Helper method to scroll to an element and click"""
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        time.sleep(0.5)
        element.click()

    def create_vendor(self, name, address, vat_no, email, mobile):
        "Navigates to Vendor Master and creates a new vendor"

        # --- Hover over "Customer & Vendor Info" ---
        customer_vendor_info = self.wait.until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Customer & Vendor Info"))
        )
        self.hover_and_click(customer_vendor_info)

        # --- Click on "Customer Master" ---
        vendor_master = self.wait.until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Vendor Master"))
        )
        vendor_master.click()

        # --- Click on "Create Vendor" ---
        create_vendor_btn = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, "//button[@id='create']"))
        )
        self.scroll_and_click(create_vendor_btn)
        time.sleep(1)  # small wait for form to load

        # --- Fill Vendor Details ---
        self.wait.until(EC.presence_of_element_located((By.ID, "vendorName"))).send_keys(name)
        time.sleep(0.5)
        self.driver.find_element(By.ID, "address").send_keys(address)
        time.sleep(0.5)
        self.driver.find_element(By.ID, "vatNo").send_keys(vat_no)
        time.sleep(0.5)
        self.driver.find_element(By.ID, "email").send_keys(email)
        time.sleep(0.5)
        self.driver.find_element(By.ID, "Mobile").send_keys(mobile)
        time.sleep(0.5)

        # --- Click Save ---
        save_button = self.wait.until(
            EC.element_to_be_clickable((By.ID, "save"))
        )
        self.scroll_and_click(save_button)

        # --- Optional: wait for success message ---
        self.wait.until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(text(),'Vendor saved successfully')]"))
        )
